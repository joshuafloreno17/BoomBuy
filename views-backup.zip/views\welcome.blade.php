<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>BoomBuy — Shop Everything You Love</title>

    <style>

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        html {
            scroll-behavior: smooth;
        }

        body {
            font-family: Arial, Helvetica, sans-serif;
            background: #f8fbff;
            color: #172033;
        }

        a {
            text-decoration: none;
        }

        /* =========================
           NAVBAR
        ========================= */

        .navbar {
            position: sticky;
            top: 0;
            z-index: 1000;

            width: 100%;

            background: rgba(255, 255, 255, 0.96);

            backdrop-filter: blur(12px);

            border-bottom: 1px solid #e5edf8;

            padding: 18px 7%;

            display: flex;
            align-items: center;
            justify-content: space-between;
        }

        .logo {
            font-size: 25px;
            font-weight: 800;
            color: #1769e0;
        }

        .logo span {
            color: #172033;
        }

        .nav-links {
            display: flex;
            align-items: center;
            gap: 28px;
        }

        .nav-links a {
            color: #475569;
            font-size: 13px;
            font-weight: 600;
        }

        .nav-links a:hover {
            color: #1769e0;
        }

        .nav-buttons {
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .login-btn {
            color: #1769e0;
            border: 1px solid #d7e5fb;
            padding: 10px 18px;
            border-radius: 8px;
            font-size: 12px;
            font-weight: 700;
        }

        .login-btn:hover {
            background: #f0f6ff;
        }

        .register-btn {
            background: #1769e0;
            color: white;
            padding: 11px 19px;
            border-radius: 8px;
            font-size: 12px;
            font-weight: 700;
        }

        .register-btn:hover {
            background: #0f55bd;
        }

        /* =========================
           HERO
        ========================= */

        .hero {
            padding: 85px 7% 75px;

            display: grid;
            grid-template-columns: 1.05fr 0.95fr;

            gap: 60px;

            align-items: center;

            background:
                radial-gradient(circle at 80% 20%, #dcecff 0, transparent 35%),
                linear-gradient(180deg, #ffffff, #f4f8ff);
        }

        .hero-content small {
            display: inline-block;

            color: #1769e0;

            background: #eaf3ff;

            padding: 8px 13px;

            border-radius: 30px;

            font-size: 10px;

            font-weight: 800;

            letter-spacing: 1.5px;

            text-transform: uppercase;

            margin-bottom: 18px;
        }

        .hero-content h1 {
            font-size: clamp(42px, 5vw, 68px);

            line-height: 1.02;

            letter-spacing: -2px;

            margin-bottom: 22px;
        }

        .hero-content h1 span {
            color: #1769e0;
        }

        .hero-content p {
            max-width: 560px;

            color: #64748b;

            font-size: 16px;

            line-height: 1.8;

            margin-bottom: 30px;
        }

        .hero-actions {
            display: flex;

            gap: 12px;

            flex-wrap: wrap;
        }

        .shop-btn {
            background: #1769e0;

            color: white;

            padding: 15px 25px;

            border-radius: 9px;

            font-size: 13px;

            font-weight: 700;

            box-shadow: 0 10px 25px rgba(23, 105, 224, 0.20);

            transition: 0.2s;
        }

        .shop-btn:hover {
            background: #0f55bd;
            transform: translateY(-2px);
        }

        .learn-btn {
            background: white;

            color: #334155;

            border: 1px solid #dce7f5;

            padding: 15px 25px;

            border-radius: 9px;

            font-size: 13px;

            font-weight: 700;
        }

        .learn-btn:hover {
            border-color: #1769e0;
            color: #1769e0;
        }

        /* =========================
           HERO VISUAL
        ========================= */

        .hero-visual {
            position: relative;

            min-height: 420px;

            display: flex;

            align-items: center;

            justify-content: center;
        }

        .hero-card {
            width: 390px;

            max-width: 100%;

            background: white;

            border: 1px solid #dfe9f7;

            border-radius: 28px;

            padding: 30px;

            box-shadow: 0 30px 70px rgba(45, 86, 145, 0.15);

            transform: rotate(2deg);
        }
.hero-product {
    height: 230px;

    border-radius: 20px;

    background:
        linear-gradient(145deg, #e8f2ff, #cfe4ff);

    display: flex;

    align-items: center;

    justify-content: center;

    font-size: 105px;

    margin-bottom: 22px;
}

.hero-product img {
    width: 180px;
    height: 180px;
    object-fit: contain;
}

        .hero-card h3 {
            font-size: 20px;

            margin-bottom: 7px;
        }

        .hero-card p {
            color: #718096;

            font-size: 12px;

            margin-bottom: 15px;
        }

        .price {
            color: #1769e0;

            font-size: 22px;

            font-weight: 800;
        }

        .floating-card {
            position: absolute;

            background: white;

            border: 1px solid #e4ebf5;

            border-radius: 14px;

            padding: 15px 18px;

            box-shadow: 0 15px 35px rgba(50, 85, 130, 0.12);

            font-size: 12px;

            font-weight: 700;
        }

        .floating-one {
            top: 30px;
            right: 0;
        }

        .floating-two {
            bottom: 35px;
            left: 5px;
        }

        /* =========================
           FEATURES
        ========================= */

        .features {
            padding: 28px 7%;

            background: white;

            border-top: 1px solid #edf2f8;

            border-bottom: 1px solid #edf2f8;

            display: grid;

            grid-template-columns: repeat(3, 1fr);

            gap: 20px;
        }

        .feature {
            display: flex;

            align-items: center;

            gap: 14px;

            padding: 10px;
        }

        .feature-icon {
            width: 45px;
            height: 45px;

            border-radius: 12px;

            background: #edf5ff;

            display: flex;

            align-items: center;

            justify-content: center;

            font-size: 21px;
        }

        .feature h4 {
            font-size: 13px;

            margin-bottom: 4px;
        }

        .feature p {
            color: #718096;

            font-size: 11px;
        }

        /* =========================
           SECTIONS
        ========================= */

        .section {
            padding: 80px 7%;
        }

        .section-header {
            text-align: center;

            margin-bottom: 40px;
        }

        .section-header small {
            color: #1769e0;

            font-size: 10px;

            font-weight: 800;

            text-transform: uppercase;

            letter-spacing: 2px;
        }

        .section-header h2 {
            font-size: 32px;

            margin-top: 8px;

            margin-bottom: 10px;
        }

        .section-header p {
            color: #718096;

            font-size: 13px;
        }

        /* =========================
           CATEGORIES
        ========================= */

        .categories {
            display: grid;

            grid-template-columns: repeat(5, 1fr);

            gap: 18px;
        }

        .category {
            background: white;

            border: 1px solid #e2eaf5;

            border-radius: 16px;

            padding: 25px 15px;

            text-align: center;

            transition: 0.25s;
        }

        .category:hover {
            transform: translateY(-5px);

            border-color: #bcd5f7;

            box-shadow: 0 15px 30px rgba(39, 84, 150, 0.08);
        }

        .category-icon {
            width: 65px;
            height: 65px;

            margin: 0 auto 15px;

            border-radius: 18px;

            background: #edf5ff;

            display: flex;

            align-items: center;

            justify-content: center;

            font-size: 31px;
        }

        .category h3 {
            font-size: 14px;

            margin-bottom: 5px;
        }

        .category p {
            color: #94a3b8;

            font-size: 11px;
        }

        /* =========================
           PRODUCTS
        ========================= */

        .products {
            display: grid;

            grid-template-columns: repeat(4, 1fr);

            gap: 20px;
        }

        .product {
            background: white;

            border: 1px solid #e2eaf5;

            border-radius: 16px;

            overflow: hidden;

            transition: 0.25s;
        }

        .product:hover {
            transform: translateY(-5px);

            box-shadow: 0 18px 35px rgba(39, 84, 150, 0.10);
        }

        .product-image {
            height: 190px;

            background: linear-gradient(145deg, #e8f2ff, #d5e8ff);

            display: flex;

            align-items: center;

            justify-content: center;

            font-size: 70px;
        }

        .product-info {
            padding: 18px;
        }

        .product-info small {
            color: #64748b;

            font-size: 10px;
        }

        .product-info h3 {
            font-size: 15px;

            margin: 7px 0;
        }

        .product-bottom {
            display: flex;

            justify-content: space-between;

            align-items: center;
        }

        .product-price {
            color: #1769e0;

            font-size: 16px;

            font-weight: 800;
        }

        .view-btn {
            color: #1769e0;

            font-size: 11px;

            font-weight: 700;
        }

        /* =========================
           CTA
        ========================= */

        .cta {
            margin: 20px 7% 80px;

            padding: 55px;

            border-radius: 24px;

            background:
                radial-gradient(circle at 90% 20%, #5b9cff 0, transparent 35%),
                linear-gradient(135deg, #1769e0, #0d55ba);

            color: white;

            display: flex;

            align-items: center;

            justify-content: space-between;

            gap: 30px;
        }

        .cta h2 {
            font-size: 32px;

            margin-bottom: 10px;
        }

        .cta p {
            font-size: 13px;

            line-height: 1.6;

            opacity: 0.85;

            max-width: 600px;
        }

        .cta-btn {
            flex-shrink: 0;

            background: white;

            color: #1769e0;

            padding: 14px 23px;

            border-radius: 9px;

            font-size: 12px;

            font-weight: 800;
        }

        .cta-btn:hover {
            background: #f0f6ff;
        }

        /* =========================
           FOOTER
        ========================= */

        footer {
            background: #111827;

            color: white;

            padding: 55px 7% 25px;
        }

        .footer-grid {
            display: grid;

            grid-template-columns: 1.5fr 1fr 1fr 1fr;

            gap: 40px;

            padding-bottom: 40px;

            border-bottom: 1px solid #263244;
        }

        .footer-brand .logo {
            display: inline-block;

            margin-bottom: 15px;
        }

        .footer-brand p {
            color: #94a3b8;

            font-size: 12px;

            line-height: 1.7;

            max-width: 300px;
        }

        footer h4 {
            font-size: 12px;

            margin-bottom: 15px;
        }

        footer ul {
            list-style: none;
        }

        footer li {
            margin-bottom: 9px;
        }

        footer li a {
            color: #94a3b8;

            font-size: 11px;
        }

        footer li a:hover {
            color: white;
        }

        .copyright {
            padding-top: 22px;

            color: #64748b;

            font-size: 10px;

            text-align: center;
        }

        /* =========================
           RESPONSIVE
        ========================= */

        @media (max-width: 900px) {

            .nav-links {
                display: none;
            }

            .hero {
                grid-template-columns: 1fr;

                text-align: center;
            }

            .hero-content p {
                margin-left: auto;
                margin-right: auto;
            }

            .hero-actions {
                justify-content: center;
            }

            .categories {
                grid-template-columns: repeat(3, 1fr);
            }

            .products {
                grid-template-columns: repeat(2, 1fr);
            }

            .features {
                grid-template-columns: 1fr;
            }

            .cta {
                flex-direction: column;

                text-align: center;
            }

            .footer-grid {
                grid-template-columns: repeat(2, 1fr);
            }
        }

        @media (max-width: 600px) {

            .navbar {
                padding: 15px 5%;
            }

            .login-btn {
                display: none;
            }

            .hero {
                padding: 60px 5%;
            }

            .hero-content h1 {
                font-size: 42px;
            }

            .section {
                padding: 60px 5%;
            }

            .categories {
                grid-template-columns: repeat(2, 1fr);
            }

            .products {
                grid-template-columns: 1fr;
            }

            .cta {
                margin-left: 5%;
                margin-right: 5%;

                padding: 35px 25px;
            }

            .footer-grid {
                grid-template-columns: 1fr;
            }

        }

    </style>

</head>

<body>


<!-- =========================
     NAVBAR
========================= -->

<nav class="navbar">

    <a href="/" class="logo">
        Boom<span>Buy</span>
    </a>


    <div class="nav-links">

        <a href="/">
            Home
        </a>

        <a href="#categories">
            Categories
        </a>

        <a href="#featured">
            Featured
        </a>

        <!-- LOGIN REQUIRED -->
        <a href="{{ route('login') }}">
            Shop
        </a>

    </div>


    <div class="nav-buttons">

        <a href="{{ route('login') }}" class="login-btn">
            Login
        </a>

        <a href="{{ route('register') }}" class="register-btn">
            Register
        </a>

    </div>

</nav>


<!-- =========================
     HERO
========================= -->

<section class="hero">

    <div class="hero-content">

        <small>
            Your Everyday Marketplace
        </small>

        <h1>
            Shop More.<br>
            <span>Live Better.</span>
        </h1>

        <p>
            Discover amazing products from trusted sellers
            all in one place. From gadgets and fashion to
            everyday essentials, BoomBuy makes online shopping
            simple, convenient, and exciting.
        </p>


        <div class="hero-actions">

            <!-- LOGIN REQUIRED -->
            <a href="{{ route('login') }}" class="shop-btn">
                Start Shopping →
            </a>

            <a href="{{ route('register') }}" class="learn-btn">
                Create Account
            </a>

        </div>

    </div>


    <div class="hero-visual">

        <div class="floating-card floating-one">
            ⭐ 4.9 Customer Rating
        </div>


        <div class="hero-card">

            <div class="hero-product">
    <img src="{{ asset('images/boombuy-logo.png') }}" alt="BoomBuy Logo">
</div>
            <h3>
                BOOMBUY
            </h3>

            <p>
                Featured product · Free delivery
            </p>

            <div class="price">
                ₱18,999
            </div>

        </div>


        <div class="floating-card floating-two">
            🚚 Fast & Reliable Delivery
        </div>

    </div>

</section>


<!-- =========================
     FEATURES
========================= -->

<section class="features">

    <div class="feature">

        <div class="feature-icon">
            🚚
        </div>

        <div>

            <h4>
                Fast Delivery
            </h4>

            <p>
                Get your orders delivered quickly.
            </p>

        </div>

    </div>


    <div class="feature">

        <div class="feature-icon">
            🔒
        </div>

        <div>

            <h4>
                Secure Shopping
            </h4>

            <p>
                Your shopping experience stays protected.
            </p>

        </div>

    </div>


    <div class="feature">

        <div class="feature-icon">
            🛍️
        </div>

        <div>

            <h4>
                Multiple Sellers
            </h4>

            <p>
                Explore products from different sellers.
            </p>

        </div>

    </div>

</section>


<!-- =========================
     CATEGORIES
========================= -->

<section class="section" id="categories">

    <div class="section-header">

        <small>
            Explore
        </small>

        <h2>
            Shop by Category
        </h2>

        <p>
            Find what you need faster.
        </p>

    </div>


    <div class="categories">


        <!-- LOGIN REQUIRED -->

        <a href="{{ route('login') }}" class="category">

            <div class="category-icon">
                📱
            </div>

            <h3>
                Electronics
            </h3>

            <p>
                Gadgets & devices
            </p>

        </a>


        <a href="{{ route('login') }}" class="category">

            <div class="category-icon">
                👕
            </div>

            <h3>
                Fashion
            </h3>

            <p>
                Style & clothing
            </p>

        </a>


        <a href="{{ route('login') }}" class="category">

            <div class="category-icon">
                🏠
            </div>

            <h3>
                Home
            </h3>

            <p>
                Home essentials
            </p>

        </a>


        <a href="{{ route('login') }}" class="category">

            <div class="category-icon">
                💄
            </div>

            <h3>
                Beauty
            </h3>

            <p>
                Beauty & care
            </p>

        </a>


        <a href="{{ route('login') }}" class="category">

            <div class="category-icon">
                🎮
            </div>

            <h3>
                Gaming
            </h3>

            <p>
                Gaming gear
            </p>

        </a>

    </div>

</section>


<!-- =========================
     FEATURED PRODUCTS
========================= -->

<section class="section" id="featured">

    <div class="section-header">

        <small>
            Popular Now
        </small>

        <h2>
            Featured Products
        </h2>

        <p>
            Some of the products shoppers love.
        </p>

    </div>


    <div class="products">


        <!-- PRODUCT 1 -->

        <div class="product">

            <div class="product-image">
                📱
            </div>

            <div class="product-info">

                <small>
                    Smartphone
                </small>

                <h3>
                    Nova X5 Pro
                </h3>

                <div class="product-bottom">

                    <span class="product-price">
                        ₱18,999
                    </span>

                    <!-- LOGIN REQUIRED -->
                    <a href="{{ route('login') }}" class="view-btn">
                        View →
                    </a>

                </div>

            </div>

        </div>


        <!-- PRODUCT 2 -->

        <div class="product">

            <div class="product-image">
                💻
            </div>

            <div class="product-info">

                <small>
                    Laptop
                </small>

                <h3>
                    AirBook 14
                </h3>

                <div class="product-bottom">

                    <span class="product-price">
                        ₱34,990
                    </span>

                    <!-- LOGIN REQUIRED -->
                    <a href="{{ route('login') }}" class="view-btn">
                        View →
                    </a>

                </div>

            </div>

        </div>


        <!-- PRODUCT 3 -->

        <div class="product">

            <div class="product-image">
                🎧
            </div>

            <div class="product-info">

                <small>
                    Audio
                </small>

                <h3>
                    SoundCore Pro
                </h3>

                <div class="product-bottom">

                    <span class="product-price">
                        ₱2,799
                    </span>

                    <!-- LOGIN REQUIRED -->
                    <a href="{{ route('login') }}" class="view-btn">
                        View →
                    </a>

                </div>

            </div>

        </div>


        <!-- PRODUCT 4 -->

        <div class="product">

            <div class="product-image">
                ⌚
            </div>

            <div class="product-info">

                <small>
                    Wearable
                </small>

                <h3>
                    FitWatch S2
                </h3>

                <div class="product-bottom">

                    <span class="product-price">
                        ₱3,499
                    </span>

                    <!-- LOGIN REQUIRED -->
                    <a href="{{ route('login') }}" class="view-btn">
                        View →
                    </a>

                </div>

            </div>

        </div>

    </div>

</section>


<!-- =========================
     CALL TO ACTION
========================= -->

<section class="cta">

    <div>

        <h2>
            Ready to start shopping?
        </h2>

        <p>
            Join BoomBuy today and discover products,
            sellers, and deals made for everyday life.
        </p>

    </div>


    <a href="{{ route('register') }}" class="cta-btn">
        Join BoomBuy →
    </a>

</section>


<!-- =========================
     FOOTER
========================= -->

<footer>

    <div class="footer-grid">


        <div class="footer-brand">

            <a href="/" class="logo">
                Boom<span>Buy</span>
            </a>

            <p>
                Your everyday online marketplace for
                products, sellers, and convenient shopping.
            </p>

        </div>


        <div>

            <h4>
                Marketplace
            </h4>

            <ul>

                <!-- LOGIN REQUIRED -->

                <li>
                    <a href="{{ route('login') }}">
                        Shop Products
                    </a>
                </li>

                <li>
                    <a href="#categories">
                        Categories
                    </a>
                </li>

                <li>
                    <a href="#featured">
                        Featured
                    </a>
                </li>

            </ul>

        </div>


        <div>

            <h4>
                Account
            </h4>

            <ul>

                <li>
                    <a href="{{ route('login') }}">
                        Login
                    </a>
                </li>

                <li>
                    <a href="{{ route('register') }}">
                        Register
                    </a>
                </li>

                <!-- LOGIN REQUIRED -->

                <li>
                    <a href="{{ route('login') }}">
                        Cart
                    </a>
                </li>

            </ul>

        </div>


        <div>

            <h4>
                BoomBuy
            </h4>

            <ul>

                <li>
                    <a href="/">
                        About Us
                    </a>
                </li>

                <li>
                    <a href="/">
                        Contact
                    </a>
                </li>

                <li>
                    <a href="/">
                        Help Center
                    </a>
                </li>

            </ul>

        </div>

    </div>


    <div class="copyright">

        © 2026 BoomBuy · Shop smarter. Live better.

    </div>

</footer>


</body>

</html>